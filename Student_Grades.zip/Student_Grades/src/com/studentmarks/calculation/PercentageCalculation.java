package com.studentmarks.calculation;

import com.exceptions.org.CustomeExceptions;
import com.studentdetails.vo.StudentDetails;

public class PercentageCalculation {
	public float percentageMarksInfo(StudentDetails stdetails)throws Exception {
		float percentage=0;
		float percentage1=0;
		try {
		int[] Marks=stdetails.getStudent_marks();
		int total=0;
		int sum=0;
		if (Marks.length==0) {
			throw new CustomeExceptions("Unable to proced .marks are not avalable..");
		}
		for(int i=0;i<Marks.length;i++) {
			sum +=Marks[i];
			
		}
		System.out.println("Marks.length"+Marks.length);
		
		total=(Marks.length*100);
		percentage=(float)sum/total;
			 percentage1=percentage*100;
		}catch(Exception e) {
			
			//System.out.println("exception cached successfully");
			e.printStackTrace();
		}
		
		return percentage1 ;
		
		
		
		
	}	
	
	

}
