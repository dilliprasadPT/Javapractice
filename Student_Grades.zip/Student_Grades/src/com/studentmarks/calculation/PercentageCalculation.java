package com.studentmarks.calculation;

import com.studentdetails.vo.StudentDetails;

public class PercentageCalculation {
	public float percentageMarksInfo(StudentDetails stdetails) {
		float percentage=0f;
		try {
		int[] Marks=stdetails.getStudent_marks();
		int total=0;
		int sum=0;
		System.out.println(Marks.length);
		for(int i=0;i<Marks.length;i++) {
			sum +=Marks[i];
		}
		total=Marks.length*100;
		percentage=(sum/total)*100;
		}catch(Exception e) {
			
			System.out.println("exception cached successfully");
			System.out.println(e);
		}
		
		return percentage ;
		
		
		
		
	}	
	
	

}
