package com.exceptions.org;

public class CustomeExceptions extends Exception{
	public CustomeExceptions(String excepmessage) {
		super(excepmessage);
	}
	

}
