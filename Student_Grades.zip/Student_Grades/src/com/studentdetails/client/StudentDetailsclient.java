package com.studentdetails.client;

import java.util.Scanner;

import com.studentdetails.vo.StudentDetails;
import com.studentmarks.calculation.PercentageCalculation;

public class StudentDetailsclient {

	public static void main(String[] args) {
		
		new StudentDetailsclient().studentDetailsinfo();
		StudentDetails details= new StudentDetails();
		new PercentageCalculation().percentageMarksInfo(details);
		
		
		
	}
		
		
		
		public void studentDetailsinfo(){
			
			Scanner sc= new Scanner(System.in);
			StudentDetails details= new StudentDetails();
			
			System.out.println("************* Student Details********************");
			System.out.println("Enter Student ID: ");
			long student_id=sc.nextLong();
			System.out.println("Enter Student Name: ");
			String student_name=sc.next();
			System.out.println("Enter Student Age: ");
			int student_age=sc.nextInt();
			System.out.println("Enter Student MobileNo: ");
			long student_mobileno=sc.nextLong();
			System.out.println("Enter Student graduationcurse : ");
			String student_graduation=sc.next();
			System.out.println("Enter number of subjects : ");
			int marks=sc.nextInt();
			int student_marks[]=new int[marks];
			System.out.println("Enter Marks : ");
			
			for(int i=0;i<=marks;i++) {
				if (i==marks) {
					System.out.println("Marks Entered Successfully.Kindly wait for some time...");
					break;
				}
				int stmarks=sc.nextInt();
				student_marks[i]=stmarks;
			}
			
			details.setStudent_id(student_id);
			details.setStudent_name(student_name);
			details.setStudent_age(student_age);
			details.setStudent_mno(student_mobileno);
			details.setStudent_graduation(student_graduation);
			details.setStudent_marks(student_marks);
			

			
		}
			
			
		

}
