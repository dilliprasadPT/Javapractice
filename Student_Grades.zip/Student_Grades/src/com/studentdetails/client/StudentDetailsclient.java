package com.studentdetails.client;

import java.io.IOException;
import java.util.Scanner;

import com.studentdetails.vo.DataIntoFile;
import com.studentdetails.vo.StudentDetails;
import com.studentmarks.calculation.PercentageCalculation;

public class StudentDetailsclient {

	public static void main(String[] args) {
		
		StudentDetails details=new StudentDetailsclient().studentDetailsinfo();
		float percentage=0;
		try {
			percentage = new PercentageCalculation().percentageMarksInfo(details);
		} catch (Exception e) {
			e.printStackTrace();
		}
		details.setStudent_percentage(percentage);
		String student_greade=new PercentageCalculation().grade(details);
		details.setStudent_greade(student_greade);
		
		DataIntoFile filedata=new DataIntoFile();
		System.out.println(details);
		try {
			filedata.fileInfo(details);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	
		public StudentDetails studentDetailsinfo(){
			
			Scanner sc= new Scanner(System.in);
			StudentDetails details= new StudentDetails();
			
			System.out.println("************* Student Details********************");
			System.out.println("Enter Student ID: ");
			long student_id=sc.nextLong();
			System.out.println("Enter Student Name: ");
			String student_name=sc.next();
			System.out.println("Enter Student Age: ");
			int student_age=sc.nextInt();
			System.out.println("Enter Student MobileNo: ");
			long student_mobileno=sc.nextLong();
			System.out.println("Enter Student graduationcurse : ");
			String student_graduation=sc.next();
			System.out.println("Enter number of subjects : ");
			int marks=sc.nextInt();
			int student_marks[]=new int[marks];
			System.out.println("Enter Marks : ");
			try {
			for(int i=0;i<=marks;i++) {
				if (i==marks) {
					System.out.println("Marks Entered Successfully.Kindly wait for some time...");
					break;
				}
				int stmarks=sc.nextInt();
				student_marks[i]=stmarks;
			}
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Please enter proper marks..");
				studentDetailsinfo();
				
			}
			
			details.setStudent_id(student_id);
			details.setStudent_name(student_name);
			details.setStudent_age(student_age);
			details.setStudent_mno(student_mobileno);
			details.setStudent_graduation(student_graduation);
			details.setStudent_marks(student_marks);
			
			return details;
			
		}
			
			
		

}
