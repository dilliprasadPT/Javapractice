package com.studentdetails.vo;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;

import com.studentdetails.client.StudentDetailsclient;

public class DataIntoFile {
	
	public void fileInfo(StudentDetails details) throws IOException {
		
		try {
			FileWriter file=new FileWriter("./resource/Student_Details.txt",true);
			try {
			BufferedWriter out = new BufferedWriter(file);
			
			PrintWriter p=new PrintWriter(out);
			try {
			p.println(details);
			}finally {
				if (p!=null) {
					p.close();
				}
			}
	
	} finally {
		file.close();
	}
	}catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	
	
	
	
	
	}		
}
