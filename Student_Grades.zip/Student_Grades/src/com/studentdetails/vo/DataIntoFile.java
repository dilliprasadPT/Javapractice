package com.studentdetails.vo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import com.studentdetails.client.StudentDetailsclient;

public class DataIntoFile {
	public void fileInfo(StudentDetails details) throws IOException {
	//StudentDetails stdetails=new StudentDetails();
		try {
		FileOutputStream f=new FileOutputStream("./resource/Student_Details.txt");
		//byte[] studentdata=Student_details.getBytes();
		//f.write(studentdata);
		PrintStream p= new PrintStream(f);
		p.print(details);
	
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	
	
	
	}
}
