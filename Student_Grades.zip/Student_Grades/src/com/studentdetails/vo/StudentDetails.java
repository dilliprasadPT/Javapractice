package com.studentdetails.vo;

import java.util.Arrays;

public class StudentDetails {
	private long student_id;
	private String student_name;
	private int student_age;
	private long student_mno;
	private String student_graduation;
	private int student_marks[];
	
	public long getStudent_id() {
		return student_id;
	}
	public void setStudent_id(long student_id) {
		this.student_id = student_id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public int getStudent_age() {
		return student_age;
	}
	public void setStudent_age(int student_age) {
		this.student_age = student_age;
	}
	public long getStudent_mno() {
		return student_mno;
	}
	public void setStudent_mno(long student_mno) {
		this.student_mno = student_mno;
	}
	public String getStudent_graduation() {
		return student_graduation;
	}
	public void setStudent_graduation(String student_graduation) {
		this.student_graduation = student_graduation;
	}
	public int[] getStudent_marks() {
		return student_marks;
	}
	public void setStudent_marks(int[] student_marks) {
		this.student_marks = student_marks;
	}

	
	

}
