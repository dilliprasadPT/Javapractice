package com.college.org;

public class Student {
//public ,private,protected
	private String sname;
	private String address;
	private int age;
	private String sid;
	
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	@Override
	public String toString() {
		return "Student [sname=" + sname + ", address=" + address + ", age=" + age + ", sid=" + sid + "]";
	}
	
}
