package com.college.org;

import java.util.Random;

public class Admin {

public Student generateStudentInfo(Candidate cand) {
	
	Student st=new Student();
	st.setAddress(cand.getAddress());
	st.setAge(cand.getAge());
	st.setSid("SI"+new Random().nextInt(1000));
	st.setSname(cand.getCname());
		
return st;
}

}


