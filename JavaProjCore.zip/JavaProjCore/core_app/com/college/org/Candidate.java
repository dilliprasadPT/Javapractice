package com.college.org;

public class Candidate {

	private String cname;
	private int crank;
	private float percentage;
	private String address;
	private  String courseGroup;
	private String contactNo;
	private int age;
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getCrank() {
		return crank;
	}
	public void setCrank(int crank) {
		this.crank = crank;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCourseGroup() {
		return courseGroup;
	}
	public void setCourseGroup(String courseGroup) {
		this.courseGroup = courseGroup;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
}
