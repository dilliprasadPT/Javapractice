package com.college.org.client;

import java.util.Scanner;

import com.college.org.Admin;
import com.college.org.Candidate;
import com.college.org.Student;

public class CandidateClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Candidate Registration");
		
		Candidate crObj=new Candidate();
		
		//crObj.
Scanner sc=new Scanner(System.in);
System.out.println("Enter Name:");
String name=sc.next();
crObj.setCname(name);
System.out.println("Enter Rank:");
int rnk=sc.nextInt();
System.out.println("Enter marks percentage:");
float per=sc.nextFloat();
System.out.println("Enter address:");
String add=sc.next();
System.out.println("Enter course name:");
String cours=sc.next();
System.out.println("Enter contact number:");
String contact=sc.next();
System.out.println("Enter Age:");
int age=sc.nextInt();


crObj.setCrank(rnk);
crObj.setPercentage(per);
crObj.setAddress(add);
crObj.setCourseGroup(cours);
crObj.setContactNo(contact);
crObj.setAge(age);

Admin admin=new Admin();
Student st=admin.generateStudentInfo(crObj);
System.out.println("student:"+st);


	}

}
