package com.customardetails.org;

public class CustomarDetails {
	private String cusfname;
	private String cuslname;
	private String cusdob;
	private int age;
	private String cuspan;
	private long cusadder;
	public String getCusfname() {
		return cusfname;
	}
	public void setCusfname(String cusfname) {
		this.cusfname = cusfname;
	}
	public String getCuslname() {
		return cuslname;
	}
	public void setCuslname(String cuslname) {
		this.cuslname = cuslname;
	}
	public String getCusdob() {
		return cusdob;
	}
	public void setCusdob(String cusdob) {
		this.cusdob = cusdob;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCuspan() {
		return cuspan;
	}
	public void setCuspan(String cuspan) {
		this.cuspan = cuspan;
	}
	public long getCusadder() {
		return cusadder;
	}
	public void setCusadder(long cusadder) {
		this.cusadder = cusadder;
	}

}
