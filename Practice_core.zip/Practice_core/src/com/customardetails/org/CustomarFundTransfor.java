package com.customardetails.org;

public class CustomarFundTransfor {
	private long befaccno;
	private String befname;
	private long tfamount;
	private long totalmount;
	
	public long getBefaccno() {
		return befaccno;
	}
	public void setBefaccno(long befaccno) {
		this.befaccno = befaccno;
	}
	public String getBefname() {
		return befname;
	}
	public void setBefname(String befname) {
		this.befname = befname;
	}
	public long getTfamount() {
		return tfamount;
	}
	public void setTfamount(long tfamount) {
		this.tfamount = tfamount;
	}
	public long getTotalmount() {
		return totalmount;
	}
	public void setTotalmount(long totalmount) {
		this.totalmount = totalmount;
	}
	@Override
	public String toString() {
		return "CustomarFundTransfor [befaccno=" + befaccno + ", befname=" + befname + ", tfamount=" + tfamount
				+ ", totalmount=" + totalmount + "]";
	}

}
