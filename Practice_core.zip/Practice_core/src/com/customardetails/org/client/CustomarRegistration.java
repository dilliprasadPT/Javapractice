package com.customardetails.org.client;

import java.util.Scanner;

import com.customardetails.org.BankAdmin;
import com.customardetails.org.CustomarCreation;
import com.customardetails.org.CustomarDetails;
import com.customardetails.org.CustomarFundTransfor;

public class CustomarRegistration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Customar Registration form....");
		
		CustomarDetails cusdetails=new CustomarDetails();
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter first name..");
		
		String fname=sc.next();
		System.out.println("Enter last name..");
		String lname=sc.next();
		System.out.println("Enter DOB..");
		String dob=sc.next();
		System.out.println("Enter age..");
		int age=sc.nextInt();
		System.out.println("Enter pan..");
		String pan=sc.next();
		System.out.println("Enter addar..");
		long addar=sc.nextLong();
		
		CustomarFundTransfor fundtransfor=new CustomarFundTransfor();
		
		System.out.println("Fund transfor....");
		System.out.println("Enter BF.Account no..");
		long bfaccno=sc.nextLong();
		System.out.println("Enter BF.name");
		String bfname=sc.next();
		System.out.println("Enter Transfor ammount..");
		long tfamount =sc.nextLong();
		
		
		
		cusdetails.setCusfname(fname);
		cusdetails.setCuslname(lname);
		cusdetails.setCusdob(dob);
		cusdetails.setAge(age);
		cusdetails.setCuspan(pan);
		cusdetails.setCusadder(addar);
		
		fundtransfor.setBefaccno(bfaccno);
		fundtransfor.setBefname(bfname);
		fundtransfor.setTfamount(tfamount);
		
		
		
		BankAdmin bank=new BankAdmin();
		CustomarCreation details=bank.getcustomardetailsinfo(cusdetails);
		System.out.println(details);
		CustomarFundTransfor fundtrasfor=bank.getfundtrasforinfo(fundtransfor);
		System.out.println(fundtrasfor);
		
		

	}

}
