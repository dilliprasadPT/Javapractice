package com.exp.basics.client;

import java.util.Scanner;

import com.exp.basics.services.MobileServices;
import com.exp.basics.vo.RechargeInfoVo;

public class MobileServicesClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MobileServicesClient().readUserData();
		
	}
	
public void	readUserData(){
		MobileServices service=new MobileServices();
		RechargeInfoVo rInfo=new RechargeInfoVo();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("#############Enter Recharge Details:");
		
		System.out.println("Enter Mobile No:");
		long mobileNO=0;
		
		mobileNO=sc.nextLong();
		
		System.out.println("Enter Circle:");
		String circle=sc.next();
		
		System.out.println("Enter NetWrok:");
		String netWork=sc.next();
		
		System.out.println("Enter Mode Of Payment:");
		String modeOfPayment=sc.next();
		
		rInfo.setMobileNO(mobileNO);
		rInfo.setCircle(circle);
		rInfo.setNetWork(netWork);
		rInfo.setModeOfPay(modeOfPayment);
		String desc=service.doRecharge(rInfo);
		
		System.out.println(desc);
	}
	
	

}
