package com.exp.basics.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.exp.basics.cexp.CustomeException;
import com.exp.basics.cexp.HeapCreatior;
import com.exp.basics.services.CalculatorService;
public class CalculatorServiceClient {
	public static void main(String[] args){
		// TODO Auto-generated method stub
		File file=null;
		FileOutputStream fos=null;
		CalculatorService service=null;
		HeapCreatior heapC=null;
			try {
				service=new CalculatorService();
				heapC=new HeapCreatior();
				
				service.programFilesOpen();
				service.doCalucation();
				//heapC.heapCreator();
				
				if(file==null || !file.isFile())
					file=new File("resources/abc.txt");
				
				fos=new FileOutputStream(file);
				String sb=new String("Hai this is new expceptin demo progdddddddddddddddddrams.sdfsdafasdf...");
				fos.write(sb.getBytes());
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				System.out.println("FileNotFoundException");
				new MobileServicesClient().readUserData();
				
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("IOException");
				new MobileServicesClient().readUserData();
				
			} catch (CustomeException e) {
				e.printStackTrace();
				System.out.println("CustomeException");
				new MobileServicesClient().readUserData();
			}finally {
				service.programFilesClose();
				try {
					
					if(fos!=null)
					fos.close();
					if(fos==null)
						System.out.println("Closed");
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		

}

	
	
	
	}