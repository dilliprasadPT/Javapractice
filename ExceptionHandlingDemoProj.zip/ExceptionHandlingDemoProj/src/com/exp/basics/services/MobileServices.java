package com.exp.basics.services;

import com.exp.basics.vo.RechargeInfoVo;

public class MobileServices {

	public String doRecharge(RechargeInfoVo rInfo) {
		String circle=rInfo.getCircle();
		float price=fetchDetailsfromDB(circle);
		rInfo.setAmount(price);
		String desc="Your Recharge Done with Price:"+rInfo.getAmount()+" Successfully";
		return desc;
	}
	
	public float fetchDetailsfromDB(String circle) {
		float planPrices = 0;
		if(circle.equals("AP")) {
			planPrices=22;
		}else if(circle.equals("TS")) {
			planPrices=400;
		}else if(circle.equals("KS")) {
			planPrices=700;
		}
		
		
		
		return planPrices;
	}
	
	
}
