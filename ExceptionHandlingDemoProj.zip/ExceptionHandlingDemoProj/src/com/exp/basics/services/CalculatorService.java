package com.exp.basics.services;

import com.exp.basics.cexp.CustomeException;
import com.exp.basics.client.MobileServicesClient;
import com.exp.basics.vo.RechargeInfoVo;

public class CalculatorService {
	public void doCalucation()throws CustomeException{
		int x=10;
		int y=0;
		int total=0;
		if(y==0) {
			throw new CustomeException("denomination is :"+y);
		}
		int i=0;
		for(i=0;i<1000000000;i++) {
		RechargeInfoVo rf=	new RechargeInfoVo();
		rf.setMobileNO(i);
		System.out.println(rf.getAmount());
		}
		
		total=x/y;
			
		System.out.println("total:"+total);
		
		int totalAdd=x+y;
		System.out.println("Add"+totalAdd);
		
		int totalSub=x-y;
		System.out.println("Sub"+totalSub);
		
	}
	
	public void resolveProblem() {
		System.out.println("Db Connected Succesfully...");
		
		new MobileServicesClient().readUserData();
	}
	int x=100;
	public void programFilesOpen() {
		System.out.println("Files are Opend"+x);
		
	}
	public void programFilesClose() {
		x=0;
		System.out.println("Files are Opend"+x);
		
	}
}
