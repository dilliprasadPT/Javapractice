package com.exp.basics.vo;

public class RechargeInfoVo {
	
private long mobileNO;
private String circle;
private float amount;
private String modeOfPay;
private String netWork;

public long getMobileNO() {
	return mobileNO;
}
public void setMobileNO(long mobileNO) {
	this.mobileNO = mobileNO;
}
public String getCircle() {
	return circle;
}
public void setCircle(String circle) {
	this.circle = circle;
}
public float getAmount() {
	return amount;
}
public void setAmount(float amount) {
	this.amount = amount;
}
public String getModeOfPay() {
	return modeOfPay;
}
public void setModeOfPay(String modeOfPay) {
	this.modeOfPay = modeOfPay;
}
public String getNetWork() {
	return netWork;
}
public void setNetWork(String netWork) {
	this.netWork = netWork;
}




}
