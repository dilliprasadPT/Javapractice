package com.exp.basics.cexp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HeapCreatior {
	  List<Integer> list = new ArrayList();
	  public  void heapCreator()throws CustomeException {
			Random random = new Random();
			while (true)
				list.add(random.nextInt());
	   }
}
