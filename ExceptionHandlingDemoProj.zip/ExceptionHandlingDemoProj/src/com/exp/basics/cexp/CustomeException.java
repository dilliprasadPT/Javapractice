package com.exp.basics.cexp;

public class CustomeException extends Throwable{
	public CustomeException(String expMsg){
		super(expMsg,new Throwable("Numerator/Divideoar"));
		
	}
}
