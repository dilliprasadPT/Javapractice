package com.servlets.college;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlets.vo.StudentVo;

public class StudentServlet extends HttpServlet {

	public StudentServlet() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String sName=req.getParameter("sName");
		String sId=req.getParameter("sId");
		String sBranch=req.getParameter("sBranch");
		String sCourse=req.getParameter("sCourse");
		String sAge=req.getParameter("sAge");
		String sMobileNo=req.getParameter("sMobileNo");
		String sEmailId=req.getParameter("sEmailId");
		boolean isValid=true;
		if(sName=="" || sName==null) {
			isValid=false;
		}
		if(sId=="" || sId==null) {
			isValid=false;
		}
		
		if(sBranch=="" || sBranch==null) {
			isValid=false;
		}
		if(sCourse=="" || sCourse==null) {
			isValid=false;
		}
		if(sAge=="" || sAge==null) {
			isValid=false;
		}
		if(sMobileNo=="" || sMobileNo==null) {
			isValid=false;
		}
		if(sEmailId=="" || sEmailId==null) {
			isValid=false;
		}
		
		if(isValid) {
			StudentVo svo = new StudentVo();
			svo.setsName(sName);
			svo.setsId(sId);
			svo.setsBranch(sBranch);
			svo.setsCourse(sCourse);
			svo.setsAge(sAge);
			svo.setsMobileNo(sMobileNo);
			svo.setsEmailId(sEmailId);
			System.out.println(svo);

			resp.setContentType("text/html");
			PrintWriter pw = resp.getWriter();

			pw.append("	<table>\r\n" + "		<tr><td>Student Name</td><td>" + svo.getsName() + "</td></tr>\r\n"
					+ "		<tr><td>Student Id</td><td>" + svo.getsId() + "</td></tr>\r\n"
					+ "		<tr><td>Student Branch</td><td>" + svo.getsBranch() + "</td></tr>\r\n"
					+ "		<tr><td>Student Course</td><td>" + svo.getsCourse() + "</td></tr>\r\n"
					+ "		<tr><td>Student Age</td><td>" + svo.getsAge() + "</td></tr>\r\n"
					+ "		<tr><td>Student MobileNo</td><td>" + svo.getsMobileNo() + "</td></tr>\r\n"
					+ "		<tr><td>Student emailId</td><td>" + svo.getsEmailId() + "</td></tr>\r\n"
					+ "		<tr><td><input type='button' value='print' onclick='window.print();'></td></tr>\r\n"
					+ "	\r\n" + "	</table>");

			pw.close();
		}else {
			resp.setContentType("text/html");
			PrintWriter pw = resp.getWriter();
			pw.append("PLEASE FILL ALL MANDATORY FIELDS....");
			pw.close();
		}
	}


}
