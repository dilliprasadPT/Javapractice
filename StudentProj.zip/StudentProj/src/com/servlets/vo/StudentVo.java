package com.servlets.vo;

public class StudentVo {
	private String sName,sId,sBranch,sCourse,sAge,sMobileNo,sEmailId;

	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	public String getsId() {
		return sId;
	}

	public void setsId(String sId) {
		this.sId = sId;
	}

	public String getsBranch() {
		return sBranch;
	}

	public void setsBranch(String sBranch) {
		this.sBranch = sBranch;
	}

	public String getsCourse() {
		return sCourse;
	}

	public void setsCourse(String sCourse) {
		this.sCourse = sCourse;
	}

	public String getsAge() {
		return sAge;
	}
	public void setsAge(String sAge) {
		this.sAge = sAge;
	}

	public String getsMobileNo() {
		return sMobileNo;
	}

	public void setsMobileNo(String sMobileNo) {
		this.sMobileNo = sMobileNo;
	}

	public String getsEmailId() {
		return sEmailId;
	}

	public void setsEmailId(String sEmailId) {
		this.sEmailId = sEmailId;
	}

	@Override
	public String toString() {
		return "StudentVo [sName=" + sName + ", sId=" + sId + ", sBranch=" + sBranch + ", sCourse=" + sCourse
				+ ", sAge=" + sAge + ", sMobileNo=" + sMobileNo + ", sEmailId=" + sEmailId + "]";
	}

}
