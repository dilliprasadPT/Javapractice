package com.bank.impl;

import com.module.bank.vo.Customer;

public class BankModuleImpl extends AbstractBankModule {

	@Override
	public String getProvidentFund() {
		// TODO Auto-generated method stub
		return "27000";
	}






}
