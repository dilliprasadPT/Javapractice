package com.bank.impl;

import com.bank.interfaces.BankModule;
import com.module.bank.vo.Customer;

public abstract  class AbstractBankModule implements BankModule {
public final static String name="rama";
	@Override
	public int addCustomerDetails(Customer cust) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int intraBankCummunication() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int helpLine() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer updateCustomerDetails(Customer cust) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteCustomerDetails(String custId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteCustomerDetailsAll() {
		// TODO Auto-generated method stub
		return 0;
	}
public abstract String getProvidentFund();
}
