package com.bank.interfaces;

import com.module.bank.vo.Customer;

public interface BankModule {
	
int addCustomerDetails(Customer cust);
Customer updateCustomerDetails(Customer cust);
int deleteCustomerDetails(String custId);
int deleteCustomerDetailsAll();

int intraBankCummunication();
int helpLine();

}