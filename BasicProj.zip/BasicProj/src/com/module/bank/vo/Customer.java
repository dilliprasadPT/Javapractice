package com.module.bank.vo;

public class Customer {
private String cname;
private String cid;
private long mobileNo;
private String accountType;
private long accountNo;

public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getCid() {
	return cid;
}
public void setCid(String cid) {
	this.cid = cid;
}
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public Customer(String cname, String cid, long mobileNo, String accountType, long accountNo) {
	super();
	this.cname = cname;
	this.cid = cid;
	this.mobileNo = mobileNo;
	this.accountType = accountType;
	this.accountNo = accountNo;
}
@Override
public String toString() {
	return "Customer [cname=" + cname + ", cid=" + cid + ", mobileNo=" + mobileNo + ", accountType=" + accountType
			+ ", accountNo=" + accountNo + "]";
}
}
