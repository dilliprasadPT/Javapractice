package com.module.bank;

import com.module.bank.vo.Customer;

public class AdminChild extends Admin {
// modifiers private ,public ,protected,default.
	@Override
	public Customer getCustomerDetails(String cid) {
		// TODO Auto-generated method stub
		if(cid.equals("SBI123")) {
			System.out.println("You Benfited from Income tax."+x);
		}
		Customer cu=new Customer("Prasad", "SBI123", 332333, "SB", 3622525);
		return cu;
	}

	
	
}
