package com.module.bank;

import com.module.bank.vo.Customer;

public class Admin {
//method overloading & method overiding.
	 int x=100;
	public Customer getCustomerDetails() {
		Customer cu=new Customer("Prasad", "SBI123", 332333, "SB", 3622525);
		return cu;
	}
	public Customer getCustomerDetails(String cid) {
		Customer cu=new Customer("Prasad", "SBI123", 332333, "SB", 3622525);
		if(cid.equals(cu.getCid())) {
			return cu;
		}
		return null;
		
	}
	
}

