package com.module.bank.client;

import com.bank.impl.AbstractBankModule;
import com.bank.impl.BankModuleImpl;
import com.module.bank.Admin;
import com.module.bank.AdminChild;

public class AdminClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Admin admin=new AdminChild();
			System.out.println(admin.getCustomerDetails("SBI123"));
			BankModuleImpl bankModule=new BankModuleImpl();
			System.out.println(AbstractBankModule.name);
	}

}
