package com.jdbc.controller;

import java.sql.Connection;
import java.util.ArrayList;

import com.jdbc.bussiness.BussinessLogic;
import com.jdbc.dao.StudentDao;
import com.jdbc.service.StudentService;
import com.jdbc.utill.JdbcUtill;
import com.jdbc.vo.StudentDetailsVo;

public class StudentController {
	
	public static void main(String[] args) {
		
		StudentDetailsVo svo=new StudentDetailsVo();
		svo.setS_Name("prasad");
		svo.setS_Id("1023");
		svo.setS_Age(30);
		svo.setS_MobileNo(846509016);
		svo.setS_Course("CSC");
		
		//JdbcUtill jdbc= new JdbcUtill();
		Connection con=new JdbcUtill().getconnection();
		StudentController clr=new StudentController();
		clr.insertinto(con,svo);
		ArrayList asd=clr.Selectdata(con);
		//System.out.println(asd);
		ArrayList asd1=clr.selectDataBYid(con, svo);
		System.out.println(asd1);
		BussinessLogic bl=new BussinessLogic();
		bl.commitTables(con, svo);
		
		
		
	}
	public int  insertinto(Connection con,StudentDetailsVo svo) {
		
		StudentService stv=new StudentService();
		
		return stv.insertinto(con,svo);
	}
	public ArrayList Selectdata(Connection con) {
		StudentService stv=new StudentService();
		return stv.Selectdata(con);
	}
	public ArrayList selectDataBYid(Connection con,StudentDetailsVo svo) {
		StudentService stv=new StudentService();
		return stv.selectDataByid(con,svo);
	}
	public int insertintocourse(Connection con,StudentDetailsVo svo) {
		StudentService stv=new StudentService();
		return stv.insertintocourse(con, svo) ;
		
	}

}
