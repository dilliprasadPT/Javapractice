package com.jdbc.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.jdbc.dao.StudentDao;
import com.jdbc.vo.StudentDetailsVo;

public class StudentService {
	StudentDao dao=new StudentDao();
	public int insertinto(Connection con,StudentDetailsVo svo) {
		return dao.insertinto(con,svo);
	}
	public ArrayList Selectdata(Connection con) {
		return dao.Selectdata(con);
	}
	public ArrayList selectDataByid(Connection con,StudentDetailsVo svo) {
		return dao.selectDataByid(con,svo);
	}
	public int insertintocourse(Connection con,StudentDetailsVo svo) {
		return dao.insertintocourse(con, svo);
		
	}
	
}
