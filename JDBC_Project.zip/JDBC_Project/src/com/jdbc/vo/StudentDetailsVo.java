package com.jdbc.vo;

public class StudentDetailsVo {
private String S_Name;
private String S_Id;
private int S_Age;
private long S_MobileNo;
private String S_Course;
public String getS_Name() {
	return S_Name;
}
public void setS_Name(String s_Name) {
	S_Name = s_Name;
}
public String getS_Id() {
	return S_Id;
}
public void setS_Id(String s_Id) {
	S_Id = s_Id;
}
public int getS_Age() {
	return S_Age;
}
public void setS_Age(int s_Age) {
	S_Age = s_Age;
}
public long getS_MobileNo() {
	return S_MobileNo;
}
public void setS_MobileNo(long s_MobileNo) {
	S_MobileNo = s_MobileNo;
}
public String getS_Course() {
	return S_Course;
}
public void setS_Course(String a_Course) {
	S_Course = a_Course;
}
@Override
public String toString() {
	return "StudentDetailsVo [S_Name=" + S_Name + ", S_Id=" + S_Id + ", S_Age=" + S_Age + ", S_MobileNo=" + S_MobileNo
			+ ", A_Course=" + S_Course + "]";
}

}
