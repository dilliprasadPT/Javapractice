package com.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.jdbc.vo.StudentDetailsVo;

public class StudentDao {

	public int insertinto(Connection con,StudentDetailsVo svo) {
		int rs = 0;
		String inquery = "insert into student_detailsinfo.st_detailsinfo (S_Id,S_Name,S_Age,S_MobileNo,S_Course) Values ('"+svo.getS_Id()+"','"+svo.getS_Name()+"',"+svo.getS_Age()+","+svo.getS_MobileNo()+",'"+svo.getS_Course()+"')";
		try {
			Statement st = con.createStatement();
			rs = st.executeUpdate(inquery);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public ArrayList Selectdata(Connection con) {
		ArrayList als = new ArrayList();
		String selquery = "select S_Id,S_Name,S_Age,S_MobileNo,S_Course from student_detailsinfo.st_detailsinfo";
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(selquery);
			if (rs != null) {
				while (rs.next()) {
					StudentDetailsVo al = new StudentDetailsVo();
					al.setS_Id(rs.getString(1));
					al.setS_Name(rs.getString(2));
					al.setS_Age(rs.getInt(3));
					al.setS_MobileNo(rs.getLong(4));
					al.setS_Course(rs.getString(5));
					als.add(al);
				}

			}
			// System.out.println(als);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return als;

	}

	public ArrayList selectDataByid(Connection con, StudentDetailsVo svo) {
		ArrayList list = new ArrayList();
		String sbid = "select * from student_detailsinfo.st_detailsinfo where S_Id="+svo.getS_Id()+"";
		try {
			java.sql.PreparedStatement psmt = con.prepareStatement(sbid);
			ResultSet rs = psmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columncount = rsmd.getColumnCount();
			if (rsmd != null) {
				while (rs.next()) {
					int i = 1;
					while (i <= columncount) {
						list.add(rs.getObject(i));
						i++;
					}
				}
				System.out.println(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public int insertintocourse(Connection con,StudentDetailsVo svo) {
		int rs = 0;
		String inquerycourse = "insert into student_detailsinfo.st_courseinfo (S_Id,S_Course) Values (?,?)";
		try {
			PreparedStatement psmt = con.prepareStatement(inquerycourse);
			//rs = st.executeUpdate(inquery);
			psmt.setString(1,svo.getS_Id() );
			psmt.setString(2, svo.getS_Course());

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

}
