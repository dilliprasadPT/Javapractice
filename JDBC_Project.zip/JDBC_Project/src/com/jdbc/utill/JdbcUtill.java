package com.jdbc.utill;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcUtill {
	public Connection getconnection() {
		Connection con=null;
		String url = "jdbc:mysql://localhost:3306/student_detailsinfo";
		String uname = "root";
		String pwd = "Quest1234";
		try {
			 con = DriverManager.getConnection(url, uname, pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return con;
	}

	public void closeconnection(Connection con) {
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
