package com.jdbc.bussiness;

import java.sql.Connection;
import java.sql.SQLException;

import com.jdbc.controller.StudentController;
import com.jdbc.vo.StudentDetailsVo;

public class BussinessLogic {
	public void commitTables(Connection con,StudentDetailsVo svo) {
	try {
		con.setAutoCommit(false);
	} catch (SQLException e) {
		e.printStackTrace();
	}
		StudentController clr=new StudentController();
		int asd=clr.insertinto(con, svo);
		int asd1=clr.insertintocourse(con, svo);
		if (asd!=0 && asd1!=0) {
			try {
				con.setAutoCommit(true);
			} catch (SQLException e) {
				e.printStackTrace();
			}try {
				con.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
	}

}
