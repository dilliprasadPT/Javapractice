package com.customardetails.org;

import java.util.Random;

public class BankAdmin {
	
	//CustomarDetails cusdetails=new CustomarDetails();
	
	public CustomarCreation getcustomardetailsinfo(CustomarDetails cusdetails) {
		
		CustomarCreation cuscreation=new CustomarCreation();
		cuscreation.setCname(cusdetails.getCusfname()+" "+ cusdetails.getCuslname());
		cuscreation.setCdob(cusdetails.getCusdob());
		cuscreation.setCaccno(new Random().nextInt(1000000000));
		
		return cuscreation;
		
	}
	
	/*public CustomarCreation getfundtrasforinfo(CustomarFundTransfor fundtrasfor) {
		
		CustomarCreation fund=new CustomarCreation();
		
		fund.setBefaccno(fundtrasfor.getBefaccno());
		fund.setBefname(fundtrasfor.getBefname());
		fund.setTfamount(fundtrasfor.getTfamount());
		fund.setTotalmount(fundtrasfor.getTotalmount()-fundtrasfor.getTfamount());
		
		
		
		return fund;
	}*/
	
	
public CustomarFundTransfor getfundtrasforinfo(CustomarFundTransfor fundtrasfor) {
		
	CustomarFundTransfor fund=new CustomarFundTransfor();
		
		fund.setBefaccno(fundtrasfor.getBefaccno());
		fund.setBefname(fundtrasfor.getBefname());
		fund.setTfamount(fundtrasfor.getTfamount());
		fund.setTotalmount(fundtrasfor.getTotalmount()-fundtrasfor.getTfamount());
		
		
		
		return fund;
	}

}
