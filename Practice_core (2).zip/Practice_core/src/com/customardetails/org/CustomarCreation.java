package com.customardetails.org;

public class CustomarCreation {
	private String cname;
	private String cdob;
	private int caccno;
	
//	private long befaccno;
//	private String befname;
//	private long tfamount;
//	private long totalmount;
//	
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCdob() {
		return cdob;
	}
	public void setCdob(String cdob) {
		this.cdob = cdob;
	}
	public int getCaccno() {
		return caccno;
	}
	public void setCaccno(int caccno) {
		this.caccno = caccno;
	}
	/*public long getBefaccno() {
		return befaccno;
	}
	public void setBefaccno(long befaccno) {
		this.befaccno = befaccno;
	}
	public String getBefname() {
		return befname;
	}
	public void setBefname(String befname) {
		this.befname = befname;
	}
	public long getTfamount() {
		return tfamount;
	}
	public void setTfamount(long tfamount) {
		this.tfamount = tfamount;
	}
	public long getTotalmount() {
		return totalmount;
	}
	public void setTotalmount(long totalmount) {
		this.totalmount = totalmount;
	}*/
	@Override
	public String toString() {
		return "CustomarCreation [cname=" + cname + ", cdob=" + cdob + ", caccno=" + caccno + "]";
	}
	

}
