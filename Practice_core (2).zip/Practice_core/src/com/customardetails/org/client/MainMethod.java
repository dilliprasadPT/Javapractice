package com.customardetails.org.client;

import java.util.Scanner;

import com.customardetails.org.BankAdmin;
import com.customardetails.org.CustomarCreation;
import com.customardetails.org.CustomarDetails;
import com.customardetails.org.CustomarFundTransfor;

public class MainMethod {

	public static void main(String[] args) {
		//CustomarDetails cusdetails=new CustomarDetails();
		//CustomarRegistration registration=new CustomarRegistration();
		//CustomarFundTransfor fundtransfor=new CustomarFundTransfor();
		
		int i=1;
//		
//		System.out.println(details);
//		CustomarFundTransfor fundtrasfor=bank.getfundtrasforinfo(fundtransfor);
//		System.out.println(fundtrasfor);
		while(i==1) {
		System.out.println("plese select option..\n1.Customar creation..\n2.Fundtransfor..");
		Scanner sc=new Scanner(System.in);
		int value=sc.nextInt();
		if (value==3) {
			System.out.println("Exit...");
			break;
		}
		
		BankAdmin bank=new BankAdmin();
		
		switch(value) {
		case 1:
			CustomarRegistration registration=new CustomarRegistration();
			//registration.customarcreationinputvalues();
			CustomarCreation details=bank.getcustomardetailsinfo(registration.customarcreationinputvalues());
			System.out.println(details);
			break;
		
		case 2:
			Fundtrasfor fund=new Fundtrasfor();
			CustomarFundTransfor fundtrasfor=bank.getfundtrasforinfo(fund.fundtrasforinputvalues());
			System.out.println(fundtrasfor);
			break;
			default:
				System.out.println("invalued option..");
		
		}
		}
		

	}

}
