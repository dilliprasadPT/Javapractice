package com.customardetails.org.client;

import java.util.Scanner;

import com.customardetails.org.BankAdmin;
import com.customardetails.org.CustomarCreation;
import com.customardetails.org.CustomarDetails;
import com.customardetails.org.CustomarFundTransfor;

public class CustomarRegistration {

		public CustomarDetails customarcreationinputvalues(){
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		
		
		System.out.println("Customar Registration form....");
		
		CustomarDetails cusdetails=new CustomarDetails();
		
		
		System.out.println("Enter first name..");
		
		String fname=sc.next();
		System.out.println("Enter last name..");
		String lname=sc.next();
		System.out.println("Enter DOB..");
		String dob=sc.next();
		System.out.println("Enter age..");
		int age=sc.nextInt();
		System.out.println("Enter pan..");
		String pan=sc.next();
		System.out.println("Enter addar..");
		long addar=sc.nextLong();
		
		cusdetails.setCusfname(fname);
		cusdetails.setCuslname(lname);
		cusdetails.setCusdob(dob);
		cusdetails.setAge(age);
		cusdetails.setCuspan(pan);
		cusdetails.setCusadder(addar);
		return cusdetails;
		
		
		}	
		

	

}
