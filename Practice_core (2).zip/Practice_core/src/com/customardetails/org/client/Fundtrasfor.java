package com.customardetails.org.client;

import java.util.Scanner;

import com.customardetails.org.CustomarFundTransfor;

public class Fundtrasfor {

	public CustomarFundTransfor fundtrasforinputvalues() {
	
	Scanner sc=new Scanner(System.in);
	
	CustomarFundTransfor fundtransfor=new CustomarFundTransfor();
			
			System.out.println("Fund transfor....");
			System.out.println("Enter BF.Account no..");
			long bfaccno=sc.nextLong();
			System.out.println("Enter BF.name");
			String bfname=sc.next();
			System.out.println("Enter Transfor ammount..");
			long tfamount =sc.nextLong();
			
			
			fundtransfor.setBefaccno(bfaccno);
			fundtransfor.setBefname(bfname);
			fundtransfor.setTfamount(tfamount);
			return fundtransfor;
	}
}
