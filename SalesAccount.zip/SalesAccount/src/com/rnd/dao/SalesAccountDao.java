package com.rnd.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SalesAccountDao {
	
	public boolean createConnection(){
		boolean token=false;
		String url="jdbc:postgresql://localhost:5432/jdb_proj";
		String user="postgres";
		String password="tiger";
		String qry="select user_id,username,email from account";
		//com.mysql.jdbc.Driver
		
		Connection con = null;
		ResultSet rs=null;
		Statement st=null;
		
		try {
			con = DriverManager.getConnection(url, user, password);
			st=con.createStatement();
			rs= st.executeQuery(qry);
			
			while(rs.next()) {
				System.out.println(rs.getString(1)+"--"+rs.getString(2)+"--"+rs.getString(3));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				st.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
			
		
		
		
		
		System.out.println(con);
		
		
		
		return token;
	}
public static void main(String argc[]) throws SQLException {
	new SalesAccountDao().createConnection();
	
	
}
}

/*interface DriverManager{
		public Connection getConnection(String url, String user, String password);
	
}*/