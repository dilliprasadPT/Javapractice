package com.jdbc.basic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Getdata {
	public Connection getconnection() throws SQLException{
		Boolean asd=false;
	String url="jdbc:mysql://localhost:3306/world";
	String username="root";
	String password="Quest1234";
	Connection con=DriverManager.getConnection(url,username,password);
	
//	Statement st=con.createStatement();
//	ResultSet rs=st.executeQuery(qury);
//	while(rs.next()) {
//		System.out.println(rs.getObject("Id"));
//	}
//	//System.out.println(con);
//	return true;
//	}
//	
	return con;
	}
	public int insertqury(Connection con,String query) throws SQLException {
		int rs=0;
		if (con!=null) {
			Statement st=con.createStatement();
			 rs=st.executeUpdate(query, 0);
			if (rs!=0) {
				System.out.println("Data inserted successfully...");
			}
		}else {
			System.out.println("DataBase Not Connected properly...");
		}
		return rs;
	}
	public ResultSet getdatafromdatabase(Connection con,String query) throws SQLException {
		ResultSet rs=null;
		Statement st=con.createStatement();
		rs=st.executeQuery(query);
		return rs;
	}
	
	public static void main(String [] args) throws SQLException {
		String qury="Insert INTO  world.prasad VALUES (1,'Dilliprasad1','Automation1')";
		String query1="Select Id,Name,Project FROM world.prasad";
		String query2="UPDATE world.prasad SET Name='prasad'";
		
		Getdata data=new Getdata();
		Connection con=data.getconnection();
		data.insertqury(con,qury);
		data.insertqury(con,query2);
		ResultSet rs=data.getdatafromdatabase(con,query1);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));
		}
		
		
	}
}
