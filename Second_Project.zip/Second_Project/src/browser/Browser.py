from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
import random


class Browser:

    def chrome_options(self):
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        #chrome_options.add_argument("--window-size=1920x1080")
        return chrome_options

    def driver_path():
        # chrome_driver="./driver/chromedriver.exe"
        # chrome_driver = "D:\\Drivers\\chromedriver.exe"
        chrome_driver = "../../drivers/chromedriver.exe"
        return chrome_driver

    def navigate_browser(self,chrome_options,chrome_driverpath):
        driver = webdriver.Chrome(chrome_options=chrome_options,executable_path=chrome_driverpath)
        return driver
    def take_scerrnshot(self,driver):
        #rand = random.randint(1,100)
        return driver.get_screenshot_as_file("../../Screenshots/"+str(random.randint(1,100))+".png")

"""browser=Browser()
browser_options=browser.chrome_options()
browser_path=browser.driver_path()
#browser.navigate_browser(browser_options,browser_path)"""