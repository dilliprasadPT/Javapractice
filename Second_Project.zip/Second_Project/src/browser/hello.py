from src.browser.Browser import Browser
br = Browser()
#Browser asd=new Browser();
chrome_path = br.driver_path()
chrome_options = br.chrome_options()
driver=br.navigate_browser(chrome_options,chrome_path)
driver.get("https://intranet.quest-global.com/intranet/Logon.aspx")
br.take_scerrnshot(driver)
driver.quit()


