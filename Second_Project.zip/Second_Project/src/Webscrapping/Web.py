from bs4 import BeautifulSoup as soup
import requests as rq
from selenium.webdriver.chrome.options import Options
from selenium import webdriver

r = rq.get("https://www.python.org/")
c=r.content
#print(c)
#asd=soup.find_all("a",{"title":"Python Job Board"})
#title="Python Job Board
soup = (c, 'html.parser')
print(soup.prettify(str(r.content)))


