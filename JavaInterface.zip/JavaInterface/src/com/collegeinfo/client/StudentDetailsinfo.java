package com.collegeinfo.client;

import java.util.Scanner;

import com.college.impl.collegeAbstractImpl;
import com.collegestudentdetails.org.StudentDetails;

public class StudentDetailsinfo {
	public StudentDetails stdetails(){
		StudentDetails details=new StudentDetails();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student Details..");
		System.out.println("Enter Student Fname..");
		String fname=sc.next();
		System.out.println("Enter Student Lname..");
		String Lname=sc.next();
		System.out.println("Enter Student DOB..");
		String sdob=sc.next();
		System.out.println("Enter Student rank..");
		long srank=sc.nextLong();
		System.out.println("Enter Student branch..");
		String sbranch=sc.next();
		details.setSfname(fname);
		details.setSlname(Lname);
		details.setSdob(sdob);
		details.setSrank(srank);
		details.setSbranch(sbranch);
		
		collegeAbstractImpl sdf=new collegeAbstractImpl();
		sdf.student_Registration(details);
		
		return details;
	}
	

}
