package com.college.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.collegeinterface.org.Collegeinfo;
import com.collegestudentdetails.org.StudentDetails;

public abstract class collegeimpl implements Collegeinfo {

	@Override
	public int student_Registration(StudentDetails stdetails) {
		// TODO Auto-generated method stub
		
		
		
		
		return 0;
	}

	@Override
	public String student_branch_allocation(int sid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update_student_details(int sid) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete_student_details(int sid) {
		// TODO Auto-generated method stub
		return 0;
	}

}
