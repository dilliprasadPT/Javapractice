package com.college.impl;

public class collegeAbstractImpl extends collegeimpl {

	@Override
	public int student_fain_Details(int sid) {
		// TODO Auto-generated method stub
		return 0;
	}

}
