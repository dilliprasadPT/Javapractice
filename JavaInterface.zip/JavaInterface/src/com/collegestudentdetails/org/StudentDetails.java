package com.collegestudentdetails.org;

public class StudentDetails {
	private String sfname;
	private String slname;
	private String sdob;
	private long srank;
	private String sbranch;
	public String getSfname() {
		return sfname;
	}
	public void setSfname(String sfname) {
		this.sfname = sfname;
	}
	public String getSlname() {
		return slname;
	}
	public void setSlname(String slname) {
		this.slname = slname;
	}
	public String getSdob() {
		return sdob;
	}
	public void setSdob(String sdob) {
		this.sdob = sdob;
	}
	public long getSrank() {
		return srank;
	}
	public void setSrank(long srank) {
		this.srank = srank;
	}
	public String getSbranch() {
		return sbranch;
	}
	public void setSbranch(String sbranch) {
		this.sbranch = sbranch;
	}

	
}
