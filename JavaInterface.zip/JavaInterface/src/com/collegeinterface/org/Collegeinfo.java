package com.collegeinterface.org;

import com.collegestudentdetails.org.StudentDetails;

public interface Collegeinfo {
	int student_Registration(StudentDetails stdetails);
	String student_branch_allocation(int sid);
	int update_student_details(int sid);
	int delete_student_details(int sid);
	int student_fain_Details(int sid);
	

}
